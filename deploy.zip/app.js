/* ============================================================
   Peak — lógica
   Sin dependencias. Datos en localStorage.
   ============================================================ */

const STORAGE_KEY = 'notas-faltas-v2';
const LEGACY_KEY = 'gradeManagerData';
const THEME_KEY = 'notas-faltas-theme';

const TYPES = {
  examenes: { label: 'Exámenes', short: 'Solo exámenes', icon: 'ico-exam' },
  trabajos: { label: 'Trabajos', short: 'Solo trabajos', icon: 'ico-work' },
  mixto: { label: 'Exámenes + trabajos', short: 'Exámenes y trabajos', icon: 'ico-mix' }
};

const DEFAULTS = () => ({
  weights: { examenes: 60, trabajos: 40 },
  attendance: { totalClasses: 30, justifiedPct: 15, unjustifiedPct: 10 },
  exams: [],
  works: [],
  absences: []
});

/* ---------- Utilidades ---------- */
const uid = () => (window.crypto && crypto.randomUUID)
  ? crypto.randomUUID()
  : 'id-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 9);

const num = (value, fallback = 0) => {
  const n = parseFloat(String(value ?? '').replace(',', '.'));
  return Number.isFinite(n) ? n : fallback;
};

const clamp = (n, min, max) => Math.min(max, Math.max(min, n));

const escapeHtml = (value) => String(value ?? '')
  .replace(/&/g, '&amp;')
  .replace(/</g, '&lt;')
  .replace(/>/g, '&gt;')
  .replace(/"/g, '&quot;')
  .replace(/'/g, '&#39;');

const formatDate = (iso) => {
  if (!iso) return '';
  const d = new Date(iso + 'T00:00:00');
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleDateString('es-ES', { day: '2-digit', month: 'short' });
};

const formatLongDate = (iso) => {
  if (!iso) return '';
  const d = new Date(iso + 'T00:00:00');
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleDateString('es-ES', { day: '2-digit', month: 'long', year: 'numeric' });
};

const todayISO = () => {
  const d = new Date();
  return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
};

const normalizeType = (type) => {
  if (type === 'examenes' || type === 'trabajos' || type === 'mixto') return type;
  if (type === 'solo_trabajos') return 'trabajos';
  if (type === 'solo_examenes') return 'examenes';
  return 'mixto';
};

/* ---------- Cálculos ---------- */
const weightedAverage = (items) => {
  if (!items || !items.length) return null;
  let sum = 0;
  let total = 0;
  items.forEach((item) => {
    sum += num(item.grade) * num(item.weight);
    total += num(item.weight);
  });
  return total > 0 ? sum / total : null;
};

const finalGrade = (subject) => {
  const examAvg = weightedAverage(subject.exams);
  const workAvg = weightedAverage(subject.works);
  const type = normalizeType(subject.type);

  if (type === 'examenes') return examAvg !== null ? examAvg : workAvg;
  if (type === 'trabajos') return workAvg !== null ? workAvg : examAvg;

  if (examAvg === null && workAvg === null) return null;
  if (examAvg === null) return workAvg;
  if (workAvg === null) return examAvg;

  const wE = num(subject.weights.examenes);
  const wT = num(subject.weights.trabajos);
  const total = wE + wT;
  if (total <= 0) return weightedAverage([...subject.exams, ...subject.works]);
  return (examAvg * wE + workAvg * wT) / total;
};

const absenceStats = (subject) => {
  const justified = subject.absences.filter((a) => a.type === 'justificada').length;
  const unjustified = subject.absences.filter((a) => a.type === 'injustificada').length;
  const total = subject.absences.length;
  const classes = Math.max(num(subject.attendance.totalClasses, 1), total);
  const maxJ = (classes * num(subject.attendance.justifiedPct)) / 100;
  const maxU = (classes * num(subject.attendance.unjustifiedPct)) / 100;
  const attendance = classes > 0 ? ((classes - total) / classes) * 100 : 100;

  return {
    justified, unjustified, total, classes, maxJ, maxU,
    attendance: clamp(attendance, 0, 100),
    jOver: justified > maxJ + 1e-9,
    uOver: unjustified > maxU + 1e-9
  };
};

const gradeTone = (grade) => {
  if (grade === null) return 'neutral';
  if (grade < 5) return 'bad';
  if (grade < 7) return 'warn';
  return 'ok';
};

const round1 = (n) => Math.round(n * 10) / 10;
const prettyNumber = (n) => (Number.isInteger(round1(n)) ? String(round1(n)) : round1(n).toFixed(1));

/* ---------- Almacenamiento ---------- */
class Store {
  constructor() {
    this.subjects = this.load();
    this.currentId = null;
  }

  load() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) return this.sanitize(JSON.parse(raw));
    } catch (err) {
      console.warn('No se pudo leer el almacenamiento', err);
    }
    return this.migrateLegacy();
  }

  migrateLegacy() {
    try {
      const raw = localStorage.getItem(LEGACY_KEY);
      if (!raw) return [];
      const legacy = JSON.parse(raw);
      if (!Array.isArray(legacy)) return [];
      const migrated = legacy.map((s) => ({
        id: s.id || uid(),
        name: s.name || 'Materia',
        color: s.color || '#6366f1',
        type: 'trabajos',
        ...DEFAULTS(),
        weights: { examenes: 0, trabajos: 100 },
        works: (s.notes || []).map((n) => ({
          id: n.id || uid(),
          name: n.description || 'Trabajo',
          grade: num(n.grade),
          weight: num(n.weight, 100),
          date: String(n.date || '').slice(0, 10)
        })),
        absences: (s.absences || []).map((a) => ({
          id: a.id || uid(),
          date: a.date || '',
          reason: a.reason || '',
          type: a.justified ? 'justificada' : 'injustificada'
        }))
      }));
      localStorage.setItem(STORAGE_KEY, JSON.stringify(migrated));
      return this.sanitize(migrated);
    } catch (err) {
      console.warn('Migración fallida', err);
      return [];
    }
  }

  sanitize(list) {
    if (!Array.isArray(list)) return [];
    return list.map((s) => {
      const d = DEFAULTS();
      return {
        id: s.id || uid(),
        name: String(s.name || 'Materia').slice(0, 60),
        color: /^#[0-9a-f]{6}$/i.test(s.color || '') ? s.color : '#6366f1',
        type: normalizeType(s.type),
        weights: {
          examenes: clamp(num(s.weights?.examenes, d.weights.examenes), 0, 100),
          trabajos: clamp(num(s.weights?.trabajos, d.weights.trabajos), 0, 100)
        },
        attendance: {
          totalClasses: clamp(num(s.attendance?.totalClasses, d.attendance.totalClasses), 1, 400),
          hoursPerWeek: s.attendance?.hoursPerWeek ? num(s.attendance.hoursPerWeek) : undefined,
          weeks: s.attendance?.weeks ? num(s.attendance.weeks) : undefined,
          justifiedPct: clamp(num(s.attendance?.justifiedPct, d.attendance.justifiedPct), 0, 100),
          unjustifiedPct: clamp(num(s.attendance?.unjustifiedPct, d.attendance.unjustifiedPct), 0, 100)
        },
        exams: (Array.isArray(s.exams) ? s.exams : []).map((e) => ({
          id: e.id || uid(),
          name: String(e.name || 'Examen').slice(0, 80),
          grade: clamp(num(e.grade), 0, 10),
          weight: clamp(num(e.weight, 100), 0.01, 100),
          date: typeof e.date === 'string' ? e.date : ''
        })),
        works: (Array.isArray(s.works) ? s.works : []).map((w) => ({
          id: w.id || uid(),
          name: String(w.name || 'Trabajo').slice(0, 80),
          grade: clamp(num(w.grade), 0, 10),
          weight: clamp(num(w.weight, 100), 0.01, 100),
          date: typeof w.date === 'string' ? w.date : ''
        })),
        absences: (Array.isArray(s.absences) ? s.absences : []).map((a) => ({
          id: a.id || uid(),
          date: typeof a.date === 'string' ? a.date : '',
          reason: String(a.reason || ''),
          type: a.type === 'injustificada' ? 'injustificada' : 'justificada'
        }))
      };
    });
  }

  save() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.subjects));
    } catch (err) {
      toast('No se pudieron guardar los datos', true);
      console.error(err);
    }
  }

  all() { return this.subjects; }
  get(id) { return this.subjects.find((s) => s.id === id) || null; }

  add(subject) {
    this.subjects.push(subject);
    this.save();
    return subject;
  }

  remove(id) {
    this.subjects = this.subjects.filter((s) => s.id !== id);
    this.save();
  }
}

/* ---------- Toast ---------- */
let toastTimer = null;
function toast(message, isBad = false) {
  const el = document.getElementById('toast');
  if (!el) return;
  el.textContent = message;
  el.classList.toggle('is-bad', Boolean(isBad));
  el.classList.add('is-visible');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('is-visible'), 2400);
}

/* ---------- App ---------- */
class App {
  constructor() {
    this.store = new Store();
    this.subjectFilter = 'all';
    this.itemFilter = 'all';
    this.itemKind = 'exam';
    this.init();
  }

  init() {
    this.applyTheme(this.loadTheme());
    this.bindTheme();
    this.bindGlobal();
    this.bindSubjectModal();
    this.bindDetail();
    this.bindItemModal();
    this.bindAbsenceModal();
    this.setEyebrow();
    this.render();
  }

  /* ----- Tema ----- */
  loadTheme() {
    try {
      const saved = localStorage.getItem(THEME_KEY);
      if (saved === 'light' || saved === 'dark') return saved;
    } catch (err) { /* ignora */ }
    return window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark';
  }

  applyTheme(theme) {
    document.documentElement.dataset.theme = theme;
    try { localStorage.setItem(THEME_KEY, theme); } catch (err) { /* ignora */ }
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', theme === 'light' ? '#f3f4fa' : '#0a0b12');
  }

  bindTheme() {
    document.getElementById('themeBtn').addEventListener('click', () => {
      const next = document.documentElement.dataset.theme === 'light' ? 'dark' : 'light';
      this.applyTheme(next);
    });
  }

  setEyebrow() {
    const now = new Date();
    const label = now.toLocaleDateString('es-ES', { weekday: 'long', day: 'numeric', month: 'long' });
    document.getElementById('eyebrow').textContent = label.charAt(0).toUpperCase() + label.slice(1);
  }

  /* ----- Modales ----- */
  openModal(id) {
    const modal = document.getElementById(id);
    if (!modal) return;
    modal.classList.add('is-open');
    document.body.style.overflow = 'hidden';
    const target = modal.querySelector('input:not([type=hidden]):not([type=radio]), select');
    if (target) setTimeout(() => target.focus({ preventScroll: true }), 70);
  }

  closeModal(id) {
    const modal = document.getElementById(id);
    if (!modal) return;
    modal.classList.remove('is-open');
    if (!document.querySelector('.modal.is-open')) document.body.style.overflow = '';
  }

  closeAllModals() {
    document.querySelectorAll('.modal.is-open').forEach((m) => m.classList.remove('is-open'));
    document.body.style.overflow = '';
  }

  /* ----- Global ----- */
  bindGlobal() {
    document.getElementById('addSubjectBtn').addEventListener('click', () => this.openSubjectModal());
    document.getElementById('emptyAddBtn').addEventListener('click', () => this.openSubjectModal());
    document.getElementById('exportBtn').addEventListener('click', () => this.exportData());
    document.getElementById('footExport').addEventListener('click', () => this.exportData());
    document.getElementById('importBtn').addEventListener('click', () => document.getElementById('importInput').click());
    document.getElementById('importInput').addEventListener('change', (e) => this.importData(e));

    document.querySelectorAll('[data-close]').forEach((btn) => {
      btn.addEventListener('click', () => this.closeModal(btn.dataset.close));
    });

    document.querySelectorAll('.modal').forEach((modal) => {
      modal.addEventListener('mousedown', (e) => {
        if (e.target === modal) this.closeModal(modal.id);
      });
    });

    document.addEventListener('keydown', (e) => {
      if (e.key !== 'Escape') return;
      const open = document.querySelectorAll('.modal.is-open');
      if (open.length) this.closeModal(open[open.length - 1].id);
    });

    document.getElementById('subjectFilters').addEventListener('click', (e) => {
      const btn = e.target.closest('[data-filter]');
      if (!btn) return;
      this.subjectFilter = btn.dataset.filter;
      document.querySelectorAll('#subjectFilters .filter').forEach((b) => {
        const active = b === btn;
        b.classList.toggle('is-active', active);
        b.setAttribute('aria-selected', String(active));
      });
      this.renderSubjects();
    });

    this.bindMobileNav();
  }

  bindMobileNav() {
    const nav = document.getElementById('mobileNav');
    if (!nav) return;

    nav.addEventListener('click', (e) => {
      const item = e.target.closest('[data-nav]');
      if (!item) return;
      nav.querySelectorAll('.mobile-nav-item').forEach((el) => el.classList.remove('is-active'));
      item.classList.add('is-active');

      if (item.dataset.nav === 'home') {
        window.scrollTo({ top: 0, behavior: 'smooth' });
        return;
      }
      if (item.dataset.nav === 'materias') {
        const el = document.getElementById('materiasSection');
        if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
        return;
      }
      if (item.dataset.nav === 'ajustes') {
        toast('Abre una materia para ajustar sus opciones', true);
        return;
      }
    });

    const addBtn = document.getElementById('mobileAddBtn');
    if (addBtn) addBtn.addEventListener('click', () => this.openSubjectModal());

    const moreBtn = document.getElementById('mobileMoreBtn');
    const sheet = document.getElementById('mobileMoreSheet');
    if (moreBtn && sheet) {
      moreBtn.addEventListener('click', () => sheet.classList.add('is-open'));
      sheet.querySelectorAll('[data-close-mobile-sheet]').forEach((btn) => {
        btn.addEventListener('click', () => sheet.classList.remove('is-open'));
      });
      sheet.addEventListener('mousedown', (e) => {
        if (e.target.classList.contains('mobile-sheet-backdrop')) sheet.classList.remove('is-open');
      });
    }

    const mobileExport = document.getElementById('mobileExportBtn');
    if (mobileExport) mobileExport.addEventListener('click', () => { document.getElementById('mobileMoreSheet').classList.remove('is-open'); this.exportData(); });

    const mobileImport = document.getElementById('mobileImportBtn');
    if (mobileImport) mobileImport.addEventListener('click', () => { document.getElementById('mobileMoreSheet').classList.remove('is-open'); document.getElementById('importInput').click(); });

    const mobileTheme = document.getElementById('mobileThemeBtn');
    if (mobileTheme) mobileTheme.addEventListener('click', () => {
      const next = document.documentElement.dataset.theme === 'light' ? 'dark' : 'light';
      this.applyTheme(next);
      document.getElementById('mobileMoreSheet').classList.remove('is-open');
      toast('Tema cambiado');
    });
  }

  /* ----- Materia: alta y edición ----- */
  bindSubjectModal() {
    document.getElementById('subjectForm').addEventListener('submit', (e) => {
      e.preventDefault();
      this.saveSubject();
    });

    document.getElementById('subjectSwatches').addEventListener('click', (e) => {
      const swatch = e.target.closest('[data-color]');
      if (!swatch) return;
      document.getElementById('subjectColor').value = swatch.dataset.color;
      this.markSwatch(swatch.dataset.color);
    });

    document.getElementById('subjectColor').addEventListener('input', (e) => this.markSwatch(e.target.value));
  }

  markSwatch(color) {
    document.querySelectorAll('#subjectSwatches [data-color]').forEach((el) => {
      el.classList.toggle('is-active', el.dataset.color.toLowerCase() === String(color).toLowerCase());
    });
  }

  selectedType(name) {
    const checked = document.querySelector(`input[name="${name}"]:checked`);
    return normalizeType(checked ? checked.value : 'mixto');
  }

  openSubjectModal(id = null) {
    const subject = id ? this.store.get(id) : null;
    document.getElementById('subjectModalTitle').textContent = subject ? 'Editar materia' : 'Nueva materia';
    document.getElementById('subjectId').value = subject ? subject.id : '';
    document.getElementById('subjectName').value = subject ? subject.name : '';
    const type = subject ? normalizeType(subject.type) : 'examenes';
    document.querySelectorAll('input[name="subjectType"]').forEach((r) => { r.checked = r.value === type; });
    const color = subject ? subject.color : '#6366f1';
    document.getElementById('subjectColor').value = color;
    this.markSwatch(color);
    this.openModal('subjectModal');
  }

  saveSubject() {
    const id = document.getElementById('subjectId').value;
    const name = document.getElementById('subjectName').value.trim();
    const type = this.selectedType('subjectType');
    const color = document.getElementById('subjectColor').value || '#6366f1';

    if (!name) {
      toast('Ponle un nombre a la materia', true);
      document.getElementById('subjectName').focus();
      return;
    }

    if (id) {
      const subject = this.store.get(id);
      if (!subject) return;
      subject.name = name;
      subject.color = color;
      subject.type = type;
      if (type === 'examenes') subject.weights = { examenes: 100, trabajos: 0 };
      if (type === 'trabajos') subject.weights = { examenes: 0, trabajos: 100 };
      if (type === 'mixto' && subject.weights.examenes + subject.weights.trabajos !== 100) {
        subject.weights = { examenes: 60, trabajos: 40 };
      }
      this.store.save();
      toast('Materia actualizada');
      if (this.store.currentId === id) this.fillDetail();
    } else {
      const subject = {
        id: uid(),
        name,
        color,
        type,
        ...DEFAULTS(),
        weights: type === 'examenes'
          ? { examenes: 100, trabajos: 0 }
          : type === 'trabajos'
            ? { examenes: 0, trabajos: 100 }
            : { examenes: 60, trabajos: 40 }
      };
      this.store.add(subject);
      toast('Materia creada');
    }

    this.closeModal('subjectModal');
    this.render();
  }

  deleteSubject(id) {
    const subject = this.store.get(id);
    if (!subject) return;
    if (!window.confirm(`¿Eliminar "${subject.name}"? Se borrarán sus evaluaciones y faltas.`)) return;
    this.store.remove(id);
    if (this.store.currentId === id) {
      this.store.currentId = null;
      this.closeModal('detailModal');
    }
    this.render();
    toast('Materia eliminada');
  }

  /* ----- Panel ----- */
  render() {
    const subjects = this.store.all();
    const grades = subjects.map((s) => finalGrade(s)).filter((g) => g !== null);
    const average = grades.length ? grades.reduce((a, b) => a + b, 0) / grades.length : null;
    const absences = subjects.reduce((acc, s) => acc + s.absences.length, 0);
    const atRisk = subjects.filter((s) => {
      const st = absenceStats(s);
      return st.jOver || st.uOver;
    }).length;

    document.getElementById('statSubjects').textContent = String(subjects.length);
    document.getElementById('statAbsences').textContent = String(absences);
    document.getElementById('statRisk').textContent = String(atRisk);

    const avgEl = document.getElementById('statAverage');
    avgEl.textContent = average === null ? '—' : average.toFixed(2);

    const ring = document.getElementById('ringAverage');
    const pct = average === null ? 0 : clamp(average / 10, 0, 1);
    ring.style.strokeDashoffset = String(326.73 * (1 - pct));
    ring.style.stroke = average === null
      ? 'var(--txt-3)'
      : average < 5 ? 'var(--bad)' : average < 7 ? 'var(--warn)' : 'var(--ok)';

    const sub = document.getElementById('heroSub');
    if (!subjects.length) {
      sub.textContent = 'Añade tu primera materia para empezar.';
    } else if (average === null) {
      sub.textContent = `${subjects.length} materia${subjects.length === 1 ? '' : 's'} sin evaluaciones todavía.`;
    } else {
      sub.textContent = `${subjects.length} materia${subjects.length === 1 ? '' : 's'} · ${absences} falta${absences === 1 ? '' : 's'} · media ${average.toFixed(2)}/10`;
    }

    document.getElementById('sectionSub').textContent = subjects.length
      ? `${subjects.length} materia${subjects.length === 1 ? '' : 's'} en este curso`
      : 'Sin materias todavía';

    this.renderSubjects();
  }

  renderSubjects() {
    const grid = document.getElementById('subjectsGrid');
    const all = this.store.all();
    const list = this.subjectFilter === 'all'
      ? all
      : all.filter((s) => normalizeType(s.type) === this.subjectFilter);

    grid.innerHTML = '';

    const isEmpty = all.length === 0;
    document.getElementById('emptyState').classList.toggle('is-visible', isEmpty);
    grid.style.display = isEmpty ? 'none' : '';
    if (isEmpty) return;

    list.forEach((subject) => grid.appendChild(this.buildCard(subject)));

    if (!list.length) {
      const note = document.createElement('p');
      note.className = 'hint';
      note.style.padding = '1.5rem 0.25rem';
      note.textContent = 'No hay materias con este tipo de evaluación.';
      grid.appendChild(note);
    }
  }

  buildCard(subject) {
    const grade = finalGrade(subject);
    const examAvg = weightedAverage(subject.exams);
    const workAvg = weightedAverage(subject.works);
    const stats = absenceStats(subject);
    const type = TYPES[normalizeType(subject.type)];

    const card = document.createElement('article');
    card.className = 'subject-card';
    card.style.setProperty('--accent', subject.color);
    card.tabIndex = 0;
    card.setAttribute('role', 'button');
    card.setAttribute('aria-label', `Abrir ${subject.name}`);

    const fal = stats.total === 0
      ? '<span class="mini-tag"><i class="dot dot-ok"></i> Sin faltas</span>'
      : `<span class="mini-tag ${stats.uOver ? 'is-bad' : stats.jOver ? 'is-warn' : ''}">
           <i class="dot ${stats.uOver ? 'dot-bad' : stats.jOver ? 'dot-warn' : 'dot-ok'}"></i>
           ${stats.justified}J · ${stats.unjustified}I
         </span>`;

    card.innerHTML = `
      <div class="card-top">
        <div class="card-titles">
          <span class="card-name">${escapeHtml(subject.name)}</span>
          <span class="badge"><span class="${type.icon}"></span>${type.short}</span>
        </div>
        <div class="card-grade">
          <strong>${grade === null ? '—' : grade.toFixed(2)}</strong>
          <span>nota final</span>
        </div>
      </div>

      <div class="card-bars">
        <div class="card-bar-row">
          <span>Exámenes</span>
          <div class="bar"><i class="bar-fill fill-exams" style="width:${examAvg === null ? 0 : clamp((examAvg / 10) * 100, 0, 100)}%"></i></div>
          <b>${examAvg === null ? '—' : examAvg.toFixed(2)}</b>
        </div>
        <div class="card-bar-row">
          <span>Trabajos</span>
          <div class="bar"><i class="bar-fill fill-works" style="width:${workAvg === null ? 0 : clamp((workAvg / 10) * 100, 0, 100)}%"></i></div>
          <b>${workAvg === null ? '—' : workAvg.toFixed(2)}</b>
        </div>
      </div>

      <div class="card-foot">
        <div class="card-foot-info">
          ${fal}
          <span class="mini-tag">Asist. ${stats.attendance.toFixed(0)}%</span>
        </div>
        <div class="mini-actions">
          <button class="icon-btn" type="button" data-edit aria-label="Editar ${escapeHtml(subject.name)}"><span class="ico-pen"></span></button>
          <button class="icon-btn" type="button" data-delete aria-label="Eliminar ${escapeHtml(subject.name)}"><span class="ico-trash"></span></button>
        </div>
      </div>
    `;

    card.addEventListener('click', (e) => {
      if (e.target.closest('[data-edit]') || e.target.closest('[data-delete]')) return;
      this.openDetail(subject.id);
    });
    card.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        this.openDetail(subject.id);
      }
    });
    card.querySelector('[data-edit]').addEventListener('click', (e) => {
      e.stopPropagation();
      this.openSubjectModal(subject.id);
    });
    card.querySelector('[data-delete]').addEventListener('click', (e) => {
      e.stopPropagation();
      this.deleteSubject(subject.id);
    });

    return card;
  }

  /* ----- Detalle ----- */
  bindDetail() {
    document.querySelectorAll('.tabs .tab').forEach((tab) => {
      tab.addEventListener('click', () => this.switchTab(tab.dataset.tab));
    });

    document.getElementById('editSubjectBtn').addEventListener('click', () => {
      if (this.store.currentId) this.openSubjectModal(this.store.currentId);
    });
    document.getElementById('railCloseBtn').addEventListener('click', () => this.closeModal('detailModal'));

    document.getElementById('addItemBtn').addEventListener('click', () => this.openItemModal());
    document.getElementById('addAbsenceBtn').addEventListener('click', () => this.openAbsenceModal());

    document.getElementById('itemFilters').addEventListener('click', (e) => {
      const btn = e.target.closest('[data-item-filter]');
      if (!btn) return;
      this.itemFilter = btn.dataset.itemFilter;
      document.querySelectorAll('#itemFilters .filter').forEach((b) => {
        const active = b === btn;
        b.classList.toggle('is-active', active);
        b.setAttribute('aria-selected', String(active));
      });
      this.renderItems(this.store.get(this.store.currentId));
    });

    document.querySelectorAll('input[name="setType"]').forEach((radio) => {
      radio.addEventListener('change', () => this.syncSettingsType());
    });

    ['setTotalClasses', 'setJustifiedPct', 'setUnjustifiedPct'].forEach((id) => {
      document.getElementById(id).addEventListener('input', () => this.updateLimitsHint());
    });
    ['setHoursPerWeek', 'setWeeks'].forEach((id) => {
      document.getElementById(id).addEventListener('input', () => this.updateHoursHint());
    });

    document.getElementById('saveSettingsBtn').addEventListener('click', () => this.saveSettings());
    document.getElementById('resetSettingsBtn').addEventListener('click', () => this.resetSettings());
    document.getElementById('deleteSubjectBtn').addEventListener('click', () => {
      if (this.store.currentId) this.deleteSubject(this.store.currentId);
    });
  }

  openDetail(id) {
    const subject = this.store.get(id);
    if (!subject) return;
    this.store.currentId = id;
    this.itemFilter = 'all';
    document.querySelectorAll('#itemFilters .filter').forEach((b) => {
      const active = b.dataset.itemFilter === 'all';
      b.classList.toggle('is-active', active);
      b.setAttribute('aria-selected', String(active));
    });
    this.fillDetail();
    this.switchTab('resumen');
    this.openModal('detailModal');
  }

  switchTab(name) {
    document.querySelectorAll('.tabs .tab').forEach((t) => {
      const active = t.dataset.tab === name;
      t.classList.toggle('is-active', active);
      t.setAttribute('aria-selected', String(active));
    });
    document.querySelectorAll('.pane').forEach((p) => p.classList.toggle('is-active', p.dataset.pane === name));
    if (name === 'ajustes') this.fillSettings();
  }

  fillDetail() {
    const subject = this.store.get(this.store.currentId);
    if (!subject) return;

    const grade = finalGrade(subject);
    const examAvg = weightedAverage(subject.exams);
    const workAvg = weightedAverage(subject.works);
    const stats = absenceStats(subject);
    const type = TYPES[normalizeType(subject.type)];

    document.getElementById('detailTitle').textContent = subject.name;
    document.getElementById('detailSubtitle').textContent = type.short;
    document.getElementById('detailColor').style.background = subject.color;
    document.getElementById('detailColor').style.boxShadow = `0 0 0 4px ${subject.color}22`;

    /* Rail */
    const finalEl = document.getElementById('resFinal');
    finalEl.textContent = grade === null ? '—' : grade.toFixed(2);
    finalEl.style.color = grade === null ? '' : `var(--${gradeTone(grade)})`;

    const railRing = document.getElementById('railRing');
    railRing.style.strokeDashoffset = String(326.73 * (1 - (grade === null ? 0 : clamp(grade / 10, 0, 1))));
    railRing.style.stroke = grade === null ? 'var(--txt-3)' : `var(--${gradeTone(grade)})`;

    document.getElementById('resFinalNote').textContent = grade === null
      ? 'Sin evaluaciones'
      : `${subject.exams.length} exám. · ${subject.works.length} trab.`;

    document.getElementById('railExams').textContent = examAvg === null ? '—' : examAvg.toFixed(2);
    document.getElementById('railWorks').textContent = workAvg === null ? '—' : workAvg.toFixed(2);
    document.getElementById('railAbsences').textContent = String(stats.total);
    document.getElementById('railAttendance').textContent = `${stats.attendance.toFixed(0)}%`;

    /* Resumen */
    document.getElementById('resTypeChip').textContent = type.label;

    const activeExams = normalizeType(subject.type) !== 'trabajos';
    const activeWorks = normalizeType(subject.type) !== 'examenes';
    const wE = activeExams ? Math.round(subject.weights.examenes) : 0;
    const wT = activeWorks ? Math.round(subject.weights.trabajos) : 0;

    document.getElementById('resWeightExams').textContent = `${wE}%`;
    document.getElementById('resWeightWorks').textContent = `${wT}%`;
    document.getElementById('meterExams').style.width = `${wE}%`;
    document.getElementById('meterWorks').style.width = `${wT}%`;
    document.getElementById('resExams').textContent = examAvg === null ? '—' : examAvg.toFixed(2);
    document.getElementById('resWorks').textContent = workAvg === null ? '—' : workAvg.toFixed(2);

    const formula = document.getElementById('resFormula');
    if (normalizeType(subject.type) === 'examenes') {
      formula.textContent = 'La nota final es la media ponderada de los exámenes.';
    } else if (normalizeType(subject.type) === 'trabajos') {
      formula.textContent = 'La nota final es la media ponderada de los trabajos.';
    } else if (examAvg === null || workAvg === null) {
      formula.textContent = `Falta ${examAvg === null ? 'algún examen' : 'algún trabajo'} para aplicar el ${wE}/${wT}. Se usa solo la parte con datos.`;
    } else {
      formula.textContent = `Exámenes × ${wE}% + trabajos × ${wT}% = nota final.`;
    }

    /* Asistencia */
    const attendanceChip = document.getElementById('resAttendanceChip');
    attendanceChip.textContent = `${stats.attendance.toFixed(0)}% asistencia`;

    document.getElementById('resJustifiedText').textContent = `${stats.justified} / ${prettyNumber(stats.maxJ)}`;
    document.getElementById('resUnjustifiedText').textContent = `${stats.unjustified} / ${prettyNumber(stats.maxU)}`;

    const jBar = document.getElementById('resJustifiedBar');
    const uBar = document.getElementById('resUnjustifiedBar');
    jBar.style.width = `${stats.maxJ > 0 ? clamp((stats.justified / stats.maxJ) * 100, 0, 100) : (stats.justified ? 100 : 0)}%`;
    uBar.style.width = `${stats.maxU > 0 ? clamp((stats.unjustified / stats.maxU) * 100, 0, 100) : (stats.unjustified ? 100 : 0)}%`;
    jBar.className = `bar-fill ${stats.jOver ? 'fill-bad' : 'fill-ok'}`;
    uBar.className = `bar-fill ${stats.uOver ? 'fill-bad' : 'fill-warn'}`;

    const hint = document.getElementById('resAttendanceHint');
    if (stats.uOver) {
      hint.textContent = `Te has pasado del límite de injustificadas (${prettyNumber(stats.maxU)}).`;
      hint.className = 'hint is-bad';
    } else if (stats.jOver) {
      hint.textContent = `Te has pasado del límite de justificadas (${prettyNumber(stats.maxJ)}).`;
      hint.className = 'hint is-warn';
    } else {
      hint.textContent = `${stats.total} falta(s) sobre ${stats.classes} clases · límites: ${subject.attendance.justifiedPct}% J / ${subject.attendance.unjustifiedPct}% I.`;
      hint.className = 'hint';
    }

    /* Contadores */
    document.getElementById('tabCountItems').textContent = String(subject.exams.length + subject.works.length);
    document.getElementById('tabCountAbsences').textContent = String(stats.total);

    /* Faltas: tarjetas */
    document.getElementById('absJustified').textContent = String(stats.justified);
    document.getElementById('absUnjustified').textContent = String(stats.unjustified);
    document.getElementById('absTotal').textContent = String(stats.total);
    document.getElementById('absJustifiedLimit').textContent = `límite ${prettyNumber(stats.maxJ)}`;
    document.getElementById('absUnjustifiedLimit').textContent = `límite ${prettyNumber(stats.maxU)}`;
    document.getElementById('absTotalNote').textContent = `de ${stats.classes} clases`;

    this.renderItems(subject);
    this.renderAbsences(subject);
  }

  /* ----- Evaluaciones ----- */
  combinedItems(subject) {
    const exams = subject.exams.map((i) => ({ ...i, kind: 'exam' }));
    const works = subject.works.map((i) => ({ ...i, kind: 'work' }));
    return [...exams, ...works].sort((a, b) => (b.date || '').localeCompare(a.date || ''));
  }

  renderItems(subject) {
    if (!subject) return;
    const list = document.getElementById('itemsList');
    const empty = document.getElementById('itemsEmpty');
    list.innerHTML = '';

    let items = this.combinedItems(subject);
    if (this.itemFilter !== 'all') items = items.filter((i) => i.kind === this.itemFilter);

    const total = subject.exams.length + subject.works.length;
    empty.classList.toggle('is-visible', items.length === 0);
    list.style.display = items.length ? '' : 'none';
    empty.querySelector('p').textContent = total === 0
      ? 'Sin evaluaciones todavía'
      : 'No hay evaluaciones de este tipo';

    items.forEach((item) => list.appendChild(this.buildItemRow(item)));

    this.renderWeightTotals(subject);
  }

  buildItemRow(item) {
    const li = document.createElement('li');
    li.className = 'row';
    const tone = gradeTone(num(item.grade));
    const isExam = item.kind === 'exam';

    li.innerHTML = `
      <span class="row-kind ${isExam ? 'exam' : 'work'}"><span class="${isExam ? 'ico-exam' : 'ico-work'}"></span></span>
      <div class="row-main">
        <span class="row-title">${escapeHtml(item.name)}</span>
        <span class="row-sub">${isExam ? 'Examen' : 'Trabajo'}${item.date ? ' · ' + escapeHtml(formatDate(item.date)) : ''}</span>
      </div>
      <span class="row-grade ${tone === 'ok' ? 'is-ok' : tone === 'warn' ? 'is-warn' : tone === 'bad' ? 'is-bad' : ''}">${num(item.grade).toFixed(1)}</span>
      <span class="row-weight">${prettyNumber(num(item.weight))}%</span>
      <div class="row-actions">
        <button class="icon-btn" type="button" data-edit aria-label="Editar"><span class="ico-pen"></span></button>
        <button class="icon-btn" type="button" data-del aria-label="Eliminar"><span class="ico-trash"></span></button>
      </div>
    `;

    li.querySelector('[data-edit]').addEventListener('click', () => this.openItemModal(item.kind, item.id));
    li.querySelector('[data-del]').addEventListener('click', () => this.deleteItem(item.kind, item.id));
    return li;
  }

  renderWeightTotals(subject) {
    const config = [
      { kind: 'exam', id: 'examsTotalLine', items: subject.exams, label: 'exámenes' },
      { kind: 'work', id: 'worksTotalLine', items: subject.works, label: 'trabajos' }
    ];

    config.forEach(({ id, items, label }) => {
      const el = document.getElementById(id);
      if (!items.length) {
        el.classList.remove('is-visible');
        return;
      }
      const total = items.reduce((acc, i) => acc + num(i.weight), 0);
      const diff = 100 - total;
      el.classList.add('is-visible');
      el.classList.toggle('is-bad', Math.abs(diff) > 0.01);

      if (Math.abs(diff) < 0.01) {
        el.innerHTML = `<span>Peso total de ${label}</span><strong>100%</strong>`;
      } else if (diff > 0) {
        el.innerHTML = `<span>Peso total de ${label}</span><strong>${prettyNumber(total)}% · faltan ${prettyNumber(diff)}%</strong>`;
      } else {
        el.innerHTML = `<span>Peso total de ${label}</span><strong>${prettyNumber(total)}% · sobran ${prettyNumber(Math.abs(diff))}%</strong>`;
      }
    });
  }

  bindItemModal() {
    document.getElementById('itemForm').addEventListener('submit', (e) => {
      e.preventDefault();
      this.saveItem();
    });

    document.querySelectorAll('input[name="itemKind"]').forEach((radio) => {
      radio.addEventListener('change', () => {
        this.itemKind = radio.value;
        this.updateItemModalLabels();
        this.updateItemHint();
      });
    });

    document.getElementById('itemWeight').addEventListener('input', () => this.updateItemHint());
  }

  openItemModal(kind = null, itemId = null) {
    const subject = this.store.get(this.store.currentId);
    if (!subject) return;

    const type = normalizeType(subject.type);
    const forced = type === 'examenes' ? 'exam' : type === 'trabajos' ? 'work' : null;
    const editing = itemId
      ? (kind === 'work' ? subject.works : subject.exams).find((i) => i.id === itemId)
      : null;

    this.itemKind = editing ? (kind === 'work' ? 'work' : 'exam') : (forced || kind || 'exam');

    const kindField = document.getElementById('itemKindField');
    const lockHint = document.getElementById('itemKindLock');
    if (forced) {
      kindField.style.display = 'none';
      lockHint.textContent = `Esta materia se evalúa solo con ${forced === 'exam' ? 'exámenes' : 'trabajos'}, así que la evaluación se guardará como ${forced === 'exam' ? 'examen' : 'trabajo'}.`;
      lockHint.className = 'hint';
    } else {
      kindField.style.display = '';
      lockHint.textContent = '';
    }

    document.querySelectorAll('input[name="itemKind"]').forEach((radio) => {
      radio.checked = radio.value === this.itemKind;
      radio.disabled = Boolean(forced);
    });

    document.getElementById('itemId').value = editing ? editing.id : '';
    document.getElementById('itemName').value = editing ? editing.name : '';
    document.getElementById('itemGrade').value = editing ? editing.grade : '';
    document.getElementById('itemWeight').value = editing ? editing.weight : '';
    document.getElementById('itemDate').value = editing ? editing.date : todayISO();
    document.getElementById('itemSubmit').textContent = editing ? 'Guardar cambios' : 'Añadir';

    this.updateItemModalLabels();
    this.updateItemHint();
    this.openModal('itemModal');
  }

  updateItemModalLabels() {
    const isExam = this.itemKind === 'exam';
    const kindField = document.getElementById('itemKindField');
    const editing = Boolean(document.getElementById('itemId').value);
    document.getElementById('itemModalTitle').textContent = (editing ? 'Editar ' : 'Añadir ') + (isExam ? 'examen' : 'trabajo');
    document.getElementById('itemNameLabel').textContent = isExam ? 'Nombre del examen' : 'Nombre del trabajo';
    document.getElementById('itemName').placeholder = isExam ? 'Ej. Examen tema 1' : 'Ej. Práctica 2';
    if (kindField.style.display === 'none') {
      document.getElementById('itemModalTitle').textContent = (editing ? 'Editar ' : 'Añadir ') + (isExam ? 'examen' : 'trabajo');
    }
  }

  updateItemHint() {
    const subject = this.store.get(this.store.currentId);
    if (!subject) return;
    const items = this.itemKind === 'exam' ? subject.exams : subject.works;
    const editingId = document.getElementById('itemId').value;
    const used = items.filter((i) => i.id !== editingId).reduce((acc, i) => acc + num(i.weight), 0);
    const remaining = Math.max(0, 100 - used);
    const hint = document.getElementById('itemHint');

    if (!items.length) {
      hint.textContent = 'Si es la única evaluación, ponle 100% de peso.';
      hint.className = 'hint';
      return;
    }
    hint.textContent = `Ya hay ${prettyNumber(used)}% asignado en ${this.itemKind === 'exam' ? 'exámenes' : 'trabajos'}. Quedan ${prettyNumber(remaining)}%.`;
    hint.className = remaining <= 0 ? 'hint is-warn' : 'hint';
  }

  saveItem() {
    const subject = this.store.get(this.store.currentId);
    if (!subject) return;

    const id = document.getElementById('itemId').value;
    const name = document.getElementById('itemName').value.trim();
    const grade = num(document.getElementById('itemGrade').value, NaN);
    const weight = num(document.getElementById('itemWeight').value, NaN);
    const date = document.getElementById('itemDate').value;

    if (!name) { toast('Falta el nombre', true); return; }
    if (!Number.isFinite(grade) || grade < 0 || grade > 10) { toast('La nota debe estar entre 0 y 10', true); return; }
    if (!Number.isFinite(weight) || weight <= 0) { toast('El peso debe ser mayor que 0', true); return; }

    const type = normalizeType(subject.type);
    const checkedKind = document.querySelector('input[name="itemKind"]:checked');
    const chosenKind = checkedKind ? checkedKind.value : this.itemKind;
    const kind = type === 'examenes' ? 'exam' : type === 'trabajos' ? 'work' : chosenKind;
    const items = kind === 'exam' ? subject.exams : subject.works;
    const payload = { id: id || uid(), name, grade, weight, date };

    if (id) {
      const index = items.findIndex((i) => i.id === id);
      if (index >= 0) items[index] = payload;
      else items.push(payload);
      // si al editar cambia de tipo, quitar del array antiguo
      const other = kind === 'exam' ? subject.works : subject.exams;
      const otherIndex = other.findIndex((i) => i.id === id);
      if (otherIndex >= 0 && index < 0) other.splice(otherIndex, 1);
    } else {
      items.push(payload);
    }

    this.itemKind = kind;
    this.store.save();
    this.closeModal('itemModal');
    this.fillDetail();
    this.render();
    toast(id ? 'Cambios guardados' : (kind === 'exam' ? 'Examen añadido' : 'Trabajo añadido'));
  }

  deleteItem(kind, id) {
    const subject = this.store.get(this.store.currentId);
    if (!subject) return;
    const items = kind === 'exam' ? subject.exams : subject.works;
    const item = items.find((i) => i.id === id);
    if (!item) return;
    if (!window.confirm(`¿Eliminar "${item.name}"?`)) return;

    if (kind === 'exam') subject.exams = items.filter((i) => i.id !== id);
    else subject.works = items.filter((i) => i.id !== id);

    this.store.save();
    this.fillDetail();
    this.render();
    toast('Evaluación eliminada');
  }

  /* ----- Faltas ----- */
  bindAbsenceModal() {
    document.getElementById('absenceForm').addEventListener('submit', (e) => {
      e.preventDefault();
      this.saveAbsence();
    });
  }

  openAbsenceModal(id = null) {
    const subject = this.store.get(this.store.currentId);
    if (!subject) return;
    const absence = id ? subject.absences.find((a) => a.id === id) : null;

    document.getElementById('absenceModalTitle').textContent = absence ? 'Editar falta' : 'Añadir falta';
    document.getElementById('absenceId').value = absence ? absence.id : '';
    document.getElementById('absenceDate').value = absence ? absence.date : todayISO();
    document.getElementById('absenceReason').value = absence ? absence.reason : '';
    document.querySelectorAll('input[name="absenceKind"]').forEach((radio) => {
      radio.checked = radio.value === (absence ? absence.type : 'justificada');
    });

    this.openModal('absenceModal');
  }

  saveAbsence() {
    const subject = this.store.get(this.store.currentId);
    if (!subject) return;

    const id = document.getElementById('absenceId').value;
    const date = document.getElementById('absenceDate').value;
    const reason = document.getElementById('absenceReason').value.trim();
    const type = document.querySelector('input[name="absenceKind"]:checked')?.value || 'justificada';

    if (!date) { toast('Elige una fecha', true); return; }

    const payload = { id: id || uid(), date, reason, type };
    if (id) {
      const index = subject.absences.findIndex((a) => a.id === id);
      if (index >= 0) subject.absences[index] = payload;
      else subject.absences.push(payload);
    } else {
      subject.absences.push(payload);
    }

    this.store.save();
    this.closeModal('absenceModal');
    this.fillDetail();
    this.render();
    toast(id ? 'Falta actualizada' : 'Falta añadida');
  }

  renderAbsences(subject) {
    const list = document.getElementById('absencesList');
    const empty = document.getElementById('absencesEmpty');
    list.innerHTML = '';

    const sorted = [...subject.absences].sort((a, b) => (b.date || '').localeCompare(a.date || ''));
    empty.classList.toggle('is-visible', sorted.length === 0);
    list.style.display = sorted.length ? '' : 'none';

    sorted.forEach((absence) => {
      const justified = absence.type === 'justificada';
      const li = document.createElement('li');
      li.className = 'row';
      li.innerHTML = `
        <span class="row-kind ${justified ? 'work' : 'exam'}">
          <span class="${justified ? 'ico-check' : 'ico-x'}"></span>
        </span>
        <div class="row-main">
          <span class="row-title">${escapeHtml(absence.reason || 'Sin motivo')}</span>
          <span class="row-sub">${absence.date ? escapeHtml(formatLongDate(absence.date)) : 'Sin fecha'}</span>
        </div>
        <span class="badge-pill ${justified ? 'ok' : 'warn'}">${justified ? 'Justificada' : 'Injustificada'}</span>
        <div class="row-actions">
          <button class="icon-btn" type="button" data-edit aria-label="Editar"><span class="ico-pen"></span></button>
          <button class="icon-btn" type="button" data-del aria-label="Eliminar"><span class="ico-trash"></span></button>
        </div>
      `;
      li.querySelector('[data-edit]').addEventListener('click', () => this.openAbsenceModal(absence.id));
      li.querySelector('[data-del]').addEventListener('click', () => this.deleteAbsence(absence.id));
      list.appendChild(li);
    });
  }

  deleteAbsence(id) {
    const subject = this.store.get(this.store.currentId);
    if (!subject) return;
    if (!window.confirm('¿Eliminar esta falta?')) return;
    subject.absences = subject.absences.filter((a) => a.id !== id);
    this.store.save();
    this.fillDetail();
    this.render();
    toast('Falta eliminada');
  }

  /* ----- Ajustes ----- */
  fillSettings() {
    const subject = this.store.get(this.store.currentId);
    if (!subject) return;
    const type = normalizeType(subject.type);

    document.querySelectorAll('input[name="setType"]').forEach((radio) => {
      radio.checked = radio.value === type;
    });

    document.getElementById('setExamWeight').value = Math.round(subject.weights.examenes);
    document.getElementById('setWorkWeight').value = Math.round(subject.weights.trabajos);
    document.getElementById('setTotalClasses').value = subject.attendance.totalClasses;
    document.getElementById('setHoursPerWeek').value = subject.attendance.hoursPerWeek ?? '';
    document.getElementById('setWeeks').value = subject.attendance.weeks ?? '';
    document.getElementById('setJustifiedPct').value = subject.attendance.justifiedPct ?? 15;
    document.getElementById('setUnjustifiedPct').value = subject.attendance.unjustifiedPct ?? 10;

    this.syncSettingsType();
    this.updateLimitsHint();
    this.updateHoursHint();
  }

  syncSettingsType() {
    const type = this.selectedType('setType');
    const row = document.getElementById('weightsRow');
    const hint = document.getElementById('weightsHint');

    if (type === 'mixto') {
      row.style.display = '';
      hint.textContent = 'Exámenes + trabajos debe sumar 100%.';
      hint.className = 'hint';
    } else {
      row.style.display = 'none';
      hint.textContent = type === 'examenes'
        ? 'La nota final usará solo exámenes.'
        : 'La nota final usará solo trabajos.';
      hint.className = 'hint';
    }
  }

  updateHoursHint() {
    const hpw = num(document.getElementById('setHoursPerWeek').value);
    const weeks = num(document.getElementById('setWeeks').value);
    const total = hpw * weeks;
    const classesInput = document.getElementById('setTotalClasses');
    const hint = document.getElementById('hoursHint');
    if (hpw > 0 && weeks > 0 && total > 0) {
      classesInput.value = Math.round(total);
      hint.textContent = `Horas totales calculadas: ${Math.round(total)} clases/horas aproximadamente.`;
    } else {
      hint.textContent = 'Pon horas por semana y semanas para calcular el total automáticamente.';
    }
    this.updateLimitsHint();
  }

  updateLimitsHint() {
    const classes = clamp(num(document.getElementById('setTotalClasses').value, 30), 1, 400);
    const jPct = clamp(num(document.getElementById('setJustifiedPct').value), 0, 100);
    const uPct = clamp(num(document.getElementById('setUnjustifiedPct').value), 0, 100);
    document.getElementById('limitsHint').textContent =
      `Con ${classes} clases: hasta ${prettyNumber((classes * jPct) / 100)} justificadas y ${prettyNumber((classes * uPct) / 100)} injustificadas.`;
  }

  saveSettings() {
    const subject = this.store.get(this.store.currentId);
    if (!subject) return;

    const type = this.selectedType('setType');
    let examenes = clamp(num(document.getElementById('setExamWeight').value), 0, 100);
    let trabajos = clamp(num(document.getElementById('setWorkWeight').value), 0, 100);

    if (type === 'examenes') { examenes = 100; trabajos = 0; }
    else if (type === 'trabajos') { examenes = 0; trabajos = 100; }
    else if (Math.abs(examenes + trabajos - 100) > 0.01) {
      toast('Exámenes + trabajos debe sumar 100%', true);
      return;
    }

    subject.type = type;
    subject.weights = { examenes, trabajos };
    subject.attendance = {
      totalClasses: clamp(num(document.getElementById('setTotalClasses').value, 30), 1, 400),
      hoursPerWeek: num(document.getElementById('setHoursPerWeek').value) || undefined,
      weeks: num(document.getElementById('setWeeks').value) || undefined,
      justifiedPct: clamp(num(document.getElementById('setJustifiedPct').value), 0, 100),
      unjustifiedPct: clamp(num(document.getElementById('setUnjustifiedPct').value), 0, 100)
    };

    this.store.save();
    this.fillDetail();
    this.fillSettings();
    this.render();
    toast('Ajustes guardados');
  }

  resetSettings() {
    const subject = this.store.get(this.store.currentId);
    if (!subject) return;
    if (!window.confirm('¿Restablecer los ajustes de esta materia?')) return;

    const d = DEFAULTS();
    subject.type = 'mixto';
    subject.weights = d.weights;
    subject.attendance = d.attendance;

    this.store.save();
    this.fillDetail();
    this.fillSettings();
    this.render();
    toast('Ajustes restablecidos');
  }

  /* ----- Datos ----- */
  exportData() {
    const payload = {
      app: 'notas-faltas',
      version: 3,
      exportedAt: new Date().toISOString(),
      subjects: this.store.all()
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `notas-faltas-${todayISO()}.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1200);
    toast('Copia de seguridad descargada');
  }

  importData(event) {
    const input = event.target;
    const file = input.files && input.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(String(reader.result));
        const list = Array.isArray(parsed) ? parsed : parsed.subjects;
        if (!Array.isArray(list)) throw new Error('Formato no válido');

        const imported = this.store.sanitize(list);
        if (!imported.length) throw new Error('Sin materias');

        const replace = this.store.all().length === 0
          ? true
          : window.confirm('Aceptar = reemplazar tus datos actuales.\nCancelar = añadir las materias del archivo.');

        this.store.subjects = replace ? imported : this.store.sanitize([...this.store.all(), ...imported]);
        this.store.save();
        this.render();
        toast(replace ? 'Datos importados' : 'Materias añadidas');
      } catch (err) {
        console.error(err);
        toast('Archivo no válido', true);
      } finally {
        input.value = '';
      }
    };
    reader.onerror = () => {
      toast('No se pudo leer el archivo', true);
      input.value = '';
    };
    reader.readAsText(file);
  }
}

document.addEventListener('DOMContentLoaded', () => {
  if (!window.app) window.app = new App();
});
